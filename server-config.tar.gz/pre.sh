#!/bin/bash

# PRE HOOK
#  Make your customisation here
CFG_FOLDER_PATH="${STEAMAPPDIR}/game/csgo/cfg"

echo "exec gamemode_deathmatch_server.cfg" >> "${CFG_FOLDER_PATH}/server.cfg"


